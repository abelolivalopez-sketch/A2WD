# Disputatio · mapa antiguo y página para cada publicación (13 oct 2026)

**Sustituye a los zips `disputatio-abel` y `disputatio-creacion-abel` de hoy.** Va sobre el commit 8281707 de `abel` y lleva los tres commits de Disputatio. No toca nada de la web de A2WD, así que no choca con `movil-abel`.

## Qué subir

- `clientes/disputatio/` entera. **Lo más limpio: borra antes la carpeta `clientes/disputatio` del repositorio si ya la tenías y copia esta**, porque se han quitado archivos (`js/eventos.js` y las fuentes Alegreya).
- `README.md`: solo añade dos líneas. Si ya las tienes o has cambiado el README, no hace falta sustituirlo:
  - En la tabla: `| Webs de clientes en desarrollo | `clientes/` (no indexadas) | [clientes/disputatio/README.md](clientes/disputatio/README.md) |`
  - En el árbol: `├── clientes/    webs de clientes en desarrollo (cada una autónoma en su carpeta)`
- `0001`, `0002` y `0003-…patch` son lo mismo en forma de cambios, por si prefieres aplicarlos.

## Con GitKraken

1. Doble clic en la rama `abel` y **Pull**.
2. Borra `clientes/disputatio` si existía y copia la del zip.
3. **Stage all changes**, mensaje `Disputatio: mapa antiguo y página para cada publicación`, **Commit** y **Push**.

## Probarlo en local

Desde la raíz del repositorio: `python -m http.server` y abre `http://localhost:8000/clientes/disputatio/`. Desde ahí se llega a todo: los puntos llevan a cada publicación y el pie lleva al espacio de creación.

## Qué cambia

- **Globo de mapa antiguo, sin colores:** papel envejecido y tinta sepia, rótulos en latín con tipografía de imprenta del siglo XVII (Oceanus Atlanticus, Europa, Africa, America Septentrionalis, Nova Hollandia…), ecuador graduado, trópicos y círculos polares, ondas en las costas y la sombra hecha con rayado de grabado.
- **Toda la web en papel y tinta**, con marco de mapa alrededor. IM Fell English para títulos y rótulos, EB Garamond para el texto. Los puntos son el símbolo de ciudad de los mapas antiguos.
- **Cada publicación en su propia página** (`disputatio.html#id`): al pulsar un punto, el globo gira hasta él y pasa a la hoja, con lugar, título, fecha, coordenadas a la antigua (48° 51′ N, 2° 21′ E), letra capital, enlaces, anterior/siguiente y «Retour au globe», que vuelve con el globo centrado en ese punto.
- El espacio de creación toma el mismo estilo y su aviso lleva a la página de la publicación.

## Probado

Chrome sin cabeza, 1440×900 y móvil 390×844: navegación globo → publicación → anterior/siguiente → vuelta al globo, página de publicación inexistente, cambio de idioma, crear y publicar desde el espacio de creación y abrir su página. Sin errores en consola.
